'use client';

import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';

interface StateManagerContextType {
  selectedItems: Set<string>;
  toggleSelection: (id: string) => void;
  clearSelection: () => void;
  selectAll: (ids: string[]) => void;
  isSelected: (id: string) => boolean;
  selectionCount: number;
}

const StateManagerContext = createContext<StateManagerContextType | undefined>(undefined);

export const useStateManager = () => {
  const context = useContext(StateManagerContext);
  if (!context) {
    throw new Error('useStateManager must be used within StateManagerProvider');
  }
  return context;
};

interface StateManagerProviderProps {
  children: React.ReactNode;
}

export const StateManagerProvider: React.FC<StateManagerProviderProps> = ({ children }) => {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());

  const toggleSelection = useCallback((id: string) => {
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  const clearSelection = useCallback(() => {
    setSelectedItems(new Set());
  }, []);

  const selectAll = useCallback((ids: string[]) => {
    setSelectedItems(new Set(ids));
  }, []);

  const isSelected = useCallback((id: string) => {
    return selectedItems.has(id);
  }, [selectedItems]);

  const value = useMemo(() => ({
    selectedItems,
    toggleSelection,
    clearSelection,
    selectAll,
    isSelected,
    selectionCount: selectedItems.size,
  }), [selectedItems, toggleSelection, clearSelection, selectAll, isSelected]);

  return (
    <StateManagerContext.Provider value={value}>
      {children}
    </StateManagerContext.Provider>
  );
};
