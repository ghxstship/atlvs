import * as React from 'react';
import { twMerge } from 'tailwind-merge';
import clsx from 'clsx';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Eye, EyeOff, CheckCircle2, AlertCircle, X } from 'lucide-react';

/**
 * Pixel-Perfect Normalized Input Component
 * Uses only semantic design tokens for all styling
 */

const inputVariants = cva(
  'flex w-full bg-background text-foreground transition-default file:border-0 file:bg-transparent file:text-size-sm file:font-weight-medium placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'border border-input focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
        filled: 'bg-muted border border-transparent focus-visible:border-input',
        ghost: 'border-0 focus-visible:ring-2 focus-visible:ring-ring',
        outline: 'border-2 border-input focus-visible:border-primary',
      },
      size: {
        xs: 'h-7 px-xs py-xs text-size-xs rounded-radius-sm',
        sm: 'h-8 px-sm py-xs text-size-sm rounded-radius-sm',
        default: 'h-10 px-md py-sm text-size-md rounded-radius-md',
        lg: 'h-12 px-lg py-md text-size-lg rounded-radius-lg',
        xl: 'h-14 px-xl py-lg text-size-xl rounded-radius-lg',
      },
      state: {
        default: '',
        error: 'border-destructive focus-visible:ring-destructive',
        success: 'border-success focus-visible:ring-success',
        warning: 'border-warning focus-visible:ring-warning',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
      state: 'default',
    },
  }
)

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof inputVariants> {
  label?: string;
  error?: string;
  success?: boolean;
  helperText?: string;
  showPasswordToggle?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  leftAddon?: React.ReactNode;
  rightAddon?: React.ReactNode;
  clearable?: boolean;
  onClear?: () => void;
  loading?: boolean;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ 
    className, 
    type = 'text',
    variant,
    size,
    state,
    label,
    error,
    success,
    helperText,
    showPasswordToggle,
    leftIcon,
    rightIcon,
    leftAddon,
    rightAddon,
    clearable,
    onClear,
    loading,
    disabled,
    ...props 
  }, ref) => {
    const [showPassword, setShowPassword] = React.useState(false);
    const [isFocused, setIsFocused] = React.useState(false);
    const [internalValue, setInternalValue] = React.useState(props.value || '');
    
    const inputType = showPasswordToggle && type === 'password' 
      ? (showPassword ? 'text' : 'password') 
      : type;

    const sizeClasses = {
      sm: 'h-8 px-md text-xs',
      md: 'h-xs px-md text-sm',
      lg: 'h-xs px-md text-base'
    };

    const variantClasses = {
      default: '',
      search: 'pl-smxl',
      success: 'border-green-500 focus:border-green-500 focus:ring-green-500/20',
      error: 'border-destructive focus:border-destructive focus:ring-destructive/20'
    };

    const handleClear = () => {
      const newValue = '';
      setInternalValue(newValue);
      if (props.onChange) {
        const syntheticEvent = {
          target: { value: newValue },
          currentTarget: { value: newValue }
        } as React.ChangeEvent<HTMLInputElement>;
        props.onChange(syntheticEvent);
      }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setInternalValue(e.target.value);
      props.onChange?.(e);
    };

    React.useEffect(() => {
      setInternalValue(props.value || '');
    }, [props.value]);

    const inputElement = (
      <div className="relative flex flex-1 items-center">
        {leftIcon && (
          <div className="absolute left-0 flex h-full items-center pl-md">
            <span className="text-muted-foreground">{leftIcon}</span>
          </div>
        )}
        <input
          type={inputType}
          className={cn(
            inputVariants({ variant, size, state, className }),
            leftIcon && 'pl-10',
            (rightIcon || clearable || loading) && 'pr-10'
          )}
          ref={ref}
          disabled={disabled || loading}
          onChange={handleChange}
          {...props}
        />
        {loading && (
          <div className="absolute right-0 flex h-full items-center pr-md">
            <svg
              className="animate-spin h-4 w-4 text-muted-foreground"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
          </div>
        )}
        {clearable && internalValue && !loading && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute right-0 flex h-full items-center pr-md text-muted-foreground hover:text-foreground transition-default"
          >
            <svg
              className="h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        )}
        {showPasswordToggle && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-0 flex h-full items-center pr-md text-muted-foreground hover:text-foreground transition-default"
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4" />
            ) : (
              <Eye className="h-4 w-4" />
            )}
          </button>
        )}
        {rightIcon && !clearable && !loading && (
          <div className="absolute right-0 flex h-full items-center pr-md">
            <span className="text-muted-foreground">{rightIcon}</span>
          </div>
        )}
      </div>
    )

    if (leftAddon || rightAddon) {
      return (
        <div className="flex">
          {leftAddon && (
            <div className="flex items-center rounded-l-radius-md border border-r-0 border-input bg-muted px-md text-muted-foreground">
              {leftAddon}
            </div>
          )}
          {inputElement}
          {rightAddon && (
            <div className="flex items-center rounded-r-radius-md border border-l-0 border-input bg-muted px-md text-muted-foreground">
              {rightAddon}
            </div>
          )}
        </div>
      )
    }

    return (
      <div className="w-full">
        {label && (
          <label className="block text-body-sm font-medium font-body text-foreground mb-sm flex items-center gap-sm">
            {label}
            {success && <CheckCircle2 className="h-4 w-4 text-green-500" />}
            {error && <AlertCircle className="h-4 w-4 text-destructive" />}
          </label>
        )}
        {inputElement}
        {(rightIcon || showPasswordToggle || clearable || loading) && (
          <div className="absolute inset-y-0 right-none pr-sm flex items-center gap-xs">
            {loading && (
              <div className="animate-spin h-4 w-4 border-2 border-muted-foreground border-t-transparent rounded-full" />
            )}
            {clearable && internalValue && !loading && (
              <button
                type="button"
                onClick={handleClear}
                className="text-muted-foreground hover:text-foreground transition-colors p-xs rounded-sm hover:bg-accent/50"
                aria-label="Clear input"
              >
                <X className="h-xs w-xs" />
              </button>
            )}
            {showPasswordToggle && (
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-muted-foreground hover:text-foreground transition-colors p-xs rounded-sm hover:bg-accent/50"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            )}
            {rightIcon && !loading && (
              <span className="text-muted-foreground">
                {rightIcon}
              </span>
            )}
          </div>
        )}
      </div>
    );
  }
)

Input.displayName = 'Input';

// Input Group Component
interface InputGroupProps {
  children: React.ReactNode
  className?: string
  label?: string
  error?: string
  hint?: string
  required?: boolean
}

export const InputGroup: React.FC<InputGroupProps> = ({
  children,
  className,
  label,
  error,
  hint,
  required,
}) => {
  return (
    <div className={cn('space-y-xs', className)}>
      {label && (
        <label className="text-size-sm font-weight-medium text-foreground">
          {label}
          {required && <span className="text-destructive ml-xs">*</span>}
        </label>
      )}
      {children}
      {hint && !error && (
        <p className="text-size-xs text-muted-foreground">{hint}</p>
      )}
      {error && (
        <p className="text-size-xs text-destructive">{error}</p>
      )}
    </div>
  )
}

export { Input, inputVariants }
