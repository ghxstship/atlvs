export interface CreateProjectClientProps {
  open: boolean;
  onClose: () => void;
}
