export type ViewType = 'grid' | 'list' | 'card' | 'table';
