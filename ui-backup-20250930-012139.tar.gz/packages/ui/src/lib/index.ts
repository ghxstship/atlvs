// Minimal implementation
export {};
